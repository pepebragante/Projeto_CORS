Backend
1. Abra o terminal e vá até a pasta do backend:
    cd src/backend
2. Instale dependencias
    npm i
npm install express cors (caso não tenha)
3. Inicie o servidor:
    node server.js
4. O backend estará rodando em:


Frontend
1. Abra outro terminal e vá até a pasta do frontend:
    cd src/frontend
2. Instale o pacote serve (se ainda não tiver):
    npm install serve
3. Inicie o servidor do frontend na porta 3000:
    serve -l 3000

Execução:
- abra o navegador em http://localhost:3000